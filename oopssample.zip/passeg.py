import oops 
class g(oops.D):
    def ru(self):
          print("This")
    def sum(self):
        pass
                


c=g()
c.ru()
c.sum()



 
